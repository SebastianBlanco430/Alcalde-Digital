# Mundo 3D de Ciudad Nova (modelo puro, sin ursina): el MapaCiudad (lugares, calles, GPS)
# más edificios con puerta y obstáculos. Es la fuente de verdad de "por dónde se puede
# caminar" en el mundo en tercera persona.
#
# Composición, no herencia: MundoCiudad guarda un MapaCiudad y delega en él todo lo que
# el GPS necesita (coordenada, grafo, lugar_en_plaza, calle_en...). Por eso las funciones
# de navegacion.py (que usan `es_transitable` por duck typing) funcionan igual con un
# mapa o con un mundo. La diferencia: aquí se camina LIBRE por toda la ciudad (calles,
# aceras, plazas, pasto) y solo estorban los obstáculos y el borde del mapa.
#
# Convención de ejes (Ursina): el plano es (x, z); con rotation_y = ψ "adelante" en el
# piso es (sin ψ, cos ψ). Lados de una fachada: 'n' = +z, 's' = -z, 'e' = +x, 'o' = -x.
#
# Colisión del jugador (círculo de radio r en p):
#   - contra una caja alineada: q = (clamp(x, xmin, xmax), clamp(z, zmin, zmax));
#     choca <=> |p - q| < r   (dentro de la caja q = p, distancia 0, choca)
#   - contra otro círculo (árbol, farola): choca <=> |p - c| < r + rc
# Tocar justo el borde (distancia == r) NO cuenta como choque.
#
# Altura: la colisión sigue siendo 2D en (x, z). La altura del suelo la da `altura(x, z)` (el
# Terreno de backend/datos/terreno.py, o 0 en un mundo plano) y cada Edificio guarda en `y` la
# altura de su umbral (la de su plaza). Con terreno, los taludes demasiado empinados
# (Terreno.caminable) tampoco son transitables: hacen de muro, salvo sobre una Escalera.

import math
import os
from dataclasses import dataclass

from backend.datos.modelos_edificios import modelo_de
from backend.grafos.mapa_ciudad import _distancia_punto_segmento
from backend.logica import escaleras_calculos as esc

RADIO_JUGADOR = 0.35
# Se puede recorrer TODO el terreno dibujado (la ladera y la favela que se ven más allá de la ciudad), no
# solo el rectángulo de las plazas: con True `es_transitable` usa limites_recorribles(); con False, los
# límites de siempre (limites()). El minimapa y los tests de la ciudad siguen usando limites().
RECORRER_TODO_EL_TERRENO = True
MARGEN_BORDE_TERRENO = 3.0       # m que se dejan sin pisar antes de que termine el terreno dibujado
# Rejilla de colisiones (rendimiento): es_transitable miraba los ~600 obstáculos de la favela en cada consulta, y
# el jugador, la cámara, los peatones y los vehículos la llaman varias veces por frame. Con la rejilla solo se
# miran los de la celda del punto. El resultado es EXACTAMENTE el mismo: cada obstáculo se apunta en todas las
# celdas que toca su caja ensanchada por radio_jugador (fuera de ella no puede chocar). False = la lista entera.
INDICE_COLISIONES = True
CELDA_COLISIONES = 8.0           # m de lado de cada celda
# Colisión del decorado que el modelo no conoce (vallas, bancos, farolas... de frontend/props_mundo.py; torres del
# teleférico; puestos). El cliente los entrega con agregar_obstaculos(). False (o ALCALDE_COLISION_PROPS=0) = el
# decorado se atraviesa como antes.
COLISION_DECORADO = True


# Índice de escaleras por celdas (rendimiento): es_transitable en un talud, perfil_escalera_en (jugador, 2 por frame) y
# los vehículos (posicion_valida: 3 puntos por intento) recorrían TODAS las escaleras (364 en el mapa grande). El índice
# devuelve las de la celda en su orden original: el resultado es idéntico. ALCALDE_ESCALERAS_INDICE=0 = la lista entera.
ESCALERAS_INDICE = True
CELDA_ESCALERAS = 8.0


def escaleras_indice_activo():
    valor = os.environ.get("ALCALDE_ESCALERAS_INDICE", "").strip().lower()
    if valor in ("0", "false", "no", "off"):
        return False
    return bool(ESCALERAS_INDICE)


def colision_decorado_activa():
    """¿El decorado entregado con agregar_obstaculos() choca? ALCALDE_COLISION_PROPS=1/0 manda sobre la constante."""
    valor = os.environ.get("ALCALDE_COLISION_PROPS", "").strip().lower()
    if valor in ("1", "true", "si", "sí", "on"):
        return True
    if valor in ("0", "false", "no", "off"):
        return False
    return bool(COLISION_DECORADO)
DISTANCIA_ENTRADA = 1.2          # m delante de la puerta donde se para el personaje
LADOS_PUERTA = ("n", "s", "e", "o")
# Rumbo (rotation_y, grados) con el que se ENTRA por cada cara: hacia dentro del edificio.
_RUMBO_ENTRADA = {"s": 0.0, "o": 90.0, "n": 180.0, "e": -90.0}
# Vector unitario hacia afuera de cada cara.
_NORMAL_FUERA = {"n": (0, 1), "s": (0, -1), "e": (1, 0), "o": (-1, 0)}
# Vector unitario A LO LARGO de cada cara: el eje +x de un modelo girado para que su frente
# (+z) mire hacia afuera (rotation_y = rumbo de entrada + 180; "derecha" = (cos ψ, -sin ψ)).
_TANGENTE = {"n": (1, 0), "s": (-1, 0), "e": (0, -1), "o": (0, 1)}


@dataclass(frozen=True)
class Obstaculo:
    """Algo que no se atraviesa. Caja alineada (cx, cz, ancho, fondo) o círculo (cx, cz, radio)."""

    tipo: str
    cx: float
    cz: float
    radio: float | None = None
    ancho: float | None = None
    fondo: float | None = None

    def __post_init__(self):
        es_circulo = self.radio is not None
        es_caja = self.ancho is not None or self.fondo is not None
        if es_circulo == es_caja:
            raise ValueError(f"Obstáculo {self.tipo!r}: indica un radio O ancho y fondo.")
        if es_circulo and self.radio <= 0:
            raise ValueError(f"Obstáculo {self.tipo!r}: el radio debe ser positivo.")
        if es_caja and (self.ancho is None or self.fondo is None or self.ancho <= 0 or self.fondo <= 0):
            raise ValueError(f"Obstáculo {self.tipo!r}: ancho y fondo deben ser positivos.")

    @property
    def es_circulo(self):
        return self.radio is not None

    @property
    def es_caja(self):
        return self.radio is None

    # True si un círculo de radio `r` centrado en (x, z) toca este obstáculo.
    def choca(self, x, z, r):
        if self.es_circulo:
            return math.hypot(x - self.cx, z - self.cz) < self.radio + r
        qx = min(max(x, self.cx - self.ancho / 2), self.cx + self.ancho / 2)
        qz = min(max(z, self.cz - self.fondo / 2), self.cz + self.fondo / 2)
        return math.hypot(x - qx, z - qz) < r


@dataclass(frozen=True)
class CasaDecorativa(Obstaculo):
    """Casa no interactiva: un obstáculo de caja que se dibuja con un modelo 3D (ver
    frontend/casas_decorativas.py). `rumbo` es la rotation_y del modelo en grados, múltiplo de
    90 para que la caja siga alineada a los ejes; `variante` elige el tinte."""

    modelo: str = ""
    rumbo: float = 0.0
    escala: float = 1.0
    variante: int = 0
    pisos: int = 1              # copias del modelo apiladas (favela: 1 o 2)
    # Factor sobre la PROFUNDIDAD del modelo (su eje z), sin tocar el ancho ni el alto: deja ajustar
    # la huella a un lote del barrio denso sin agrandar la casa. 1.0 = proporciones del modelo.
    estiramiento: float = 1.0

    def __post_init__(self):
        super().__post_init__()
        if not self.modelo or not self.es_caja:
            raise ValueError("Casa decorativa: necesita un modelo y una caja (ancho y fondo).")
        if self.rumbo % 90 != 0:
            raise ValueError(f"Casa decorativa: el rumbo {self.rumbo} no es múltiplo de 90.")
        if self.pisos < 1:
            raise ValueError("Casa decorativa: necesita al menos un piso.")
        if self.estiramiento <= 0:
            raise ValueError("Casa decorativa: el estiramiento debe ser positivo.")

    @property
    def alto_piso(self):
        """Alto en m de un piso: el del modelo por su escala."""
        return modelo_de(self.modelo).alto * self.escala

    @property
    def alto_total(self):
        """Alto en m de la casa entera (todos sus pisos apilados)."""
        return self.alto_piso * self.pisos

    @property
    def hondo_umbral(self):
        """Cuántos m baja el plinto del modelo por debajo del umbral (y del piso de la casa)."""
        return modelo_de(self.modelo).hondo * self.escala


@dataclass(frozen=True)
class Escalera:
    """Escalera de la favela, de (ax, az) a (bx, bz) y `ancho` m: se dibuja con peldaños que
    siguen el suelo y deja caminar por taludes que de otro modo serían muro."""

    ax: float
    az: float
    bx: float
    bz: float
    ancho: float = 1.6

    def __post_init__(self):
        if self.ancho <= 0 or math.hypot(self.bx - self.ax, self.bz - self.az) <= 0:
            raise ValueError("Escalera: necesita largo y ancho positivos.")

    @property
    def largo(self):
        return math.hypot(self.bx - self.ax, self.bz - self.az)

    def contiene(self, x, z):
        return _distancia_punto_segmento((x, z), (self.ax, self.az), (self.bx, self.bz)) <= self.ancho / 2


@dataclass(frozen=True)
class Callejon:
    """Pasillo peatonal entre dos casas de la favela: eje (ax, az) -> (bx, bz) y `ancho` libre en m.
    Es un dato de DECORADO y de pruebas (el movimiento lo resuelven las casas como obstáculos)."""

    ax: float
    az: float
    bx: float
    bz: float
    ancho: float

    @property
    def largo(self):
        return math.hypot(self.bx - self.ax, self.bz - self.az)


@dataclass(frozen=True)
class Zona:
    """Rectángulo abierto reservado (sin casas) con un uso: 'cancha' de fútbol, 'mercado'...
    Caja alineada (cx, cz, ancho en x, fondo en z); se camina libremente por ella."""

    tipo: str
    cx: float
    cz: float
    ancho: float
    fondo: float
    rumbo: float = 0.0      # grados: hacia dónde mira lo que hay dentro (los rincones secretos; la cancha no lo usa)

    def caja(self):
        return (self.cx - self.ancho / 2, self.cx + self.ancho / 2,
                self.cz - self.fondo / 2, self.cz + self.fondo / 2)


@dataclass(frozen=True)
class Edificio:
    """Un edificio por lugar: caja (cx, cz, ancho en x, fondo en z, alto) con UNA puerta."""

    lugar: str
    cx: float
    cz: float
    ancho: float
    fondo: float
    alto: float
    lado_puerta: str
    nombre: str = ""            # texto del letrero; vacío = el nombre del lugar
    modelo: str = ""            # modelo 3D (backend/datos/modelos_edificios.py); vacío = cubos
    desfase_puerta: float = 0.0  # m desde el centro de la cara, a lo largo de _TANGENTE
    y: float = 0.0              # altura del umbral de la puerta (= su plaza en la ladera)

    def __post_init__(self):
        if self.lado_puerta not in LADOS_PUERTA:
            raise ValueError(f"lado_puerta debe ser uno de {LADOS_PUERTA}, no {self.lado_puerta!r}.")
        if self.ancho <= 0 or self.fondo <= 0 or self.alto <= 0:
            raise ValueError(f"El edificio de {self.lugar!r} necesita ancho, fondo y alto positivos.")
        if abs(self.desfase_puerta) >= self.frente / 2:
            raise ValueError(f"La puerta de {self.lugar!r} queda fuera de su fachada.")

    # Largo de la fachada con la puerta.
    @property
    def frente(self):
        return self.ancho if self.lado_puerta in ("n", "s") else self.fondo

    @property
    def titulo(self):
        return self.nombre or self.lugar

    # Puerta: sobre la fachada `lado_puerta`, en su centro corrido `desfase_puerta` m a lo largo.
    def puerta(self):
        nx, nz = _NORMAL_FUERA[self.lado_puerta]
        tx, tz = _TANGENTE[self.lado_puerta]
        return (self.cx + nx * self.ancho / 2 + tx * self.desfase_puerta,
                self.cz + nz * self.fondo / 2 + tz * self.desfase_puerta)

    # Punto de la calle `distancia` m delante de la puerta (donde se para el personaje).
    def punto_entrada(self, distancia=DISTANCIA_ENTRADA):
        nx, nz = _NORMAL_FUERA[self.lado_puerta]
        px, pz = self.puerta()
        return (px + nx * distancia, pz + nz * distancia)

    # Rumbo (rotation_y en grados) con el que se cruza la puerta hacia dentro.
    def rumbo_puerta(self):
        return _RUMBO_ENTRADA[self.lado_puerta]

    # (xmin, xmax, zmin, zmax) de la caja.
    def caja(self):
        return (self.cx - self.ancho / 2, self.cx + self.ancho / 2,
                self.cz - self.fondo / 2, self.cz + self.fondo / 2)

    def como_obstaculo(self):
        return Obstaculo("edificio", self.cx, self.cz, ancho=self.ancho, fondo=self.fondo)


class MundoCiudad:

    # `spawns` ({nombre: (x, z)}) es opcional: si se da, cada uno debe ser transitable.
    # `margen_edificios` ensancha los límites alrededor de los edificios que sobresalen del
    # mapa (0 = el borde pasa pegado a la pared).
    # ValueError si un edificio es de un lugar inexistente o repetido, tapa una plaza o una
    # calle, o si alguna puerta, punto de entrada o spawn no es transitable.
    def __init__(self, mapa, edificios, obstaculos, radio_jugador=RADIO_JUGADOR,
                 spawns=None, margen_edificios=0.0, terreno=None, escaleras=(), muros=(),
                 callejones=(), zonas=()):
        if radio_jugador <= 0:
            raise ValueError("radio_jugador debe ser positivo.")
        self._mapa = mapa
        self._edificios = list(edificios)
        self._obstaculos = list(obstaculos)
        self.radio_jugador = radio_jugador
        self.spawns = dict(spawns) if spawns else {}
        self._por_lugar = {}

        for edificio in self._edificios:
            self._validar_edificio(edificio)
            self._por_lugar[edificio.lugar] = edificio

        self._extra = {}                 # origen -> obstáculos del decorado del cliente (ver agregar_obstaculos)
        self._fisicos = [e.como_obstaculo() for e in self._edificios] + self._obstaculos
        self._celdas = _indexar(self._fisicos, radio_jugador) if INDICE_COLISIONES else None
        self.terreno = terreno           # objeto con altura(x, z); None = mundo plano
        self._escaleras = list(escaleras)
        self._muros = list(muros)        # losas de contención (backend/datos/muros.py): solo se dibujan
        self._callejones = list(callejones)   # pasillos entre casas (decorado y pruebas)
        self._zonas = list(zonas)             # canchas y otras áreas abiertas (decorado)
        self._limites = self._calcular_limites(margen_edificios)
        self._limites_recorribles = self._calcular_limites_recorribles()
        self._perfiles_escalera = None   # perfiles de peldaños (se arman al primer uso, ver perfiles_escaleras)
        self._celdas_escaleras = None    # {celda: (índices de escalera,)} (se arma al primer uso, ver escaleras_en)

        for edificio in self._edificios:
            if not self._puerta_libre(edificio):
                raise ValueError(f"La puerta de {edificio.lugar!r} está bloqueada o fuera de los límites.")
            ex, ez = edificio.punto_entrada()
            if not self.es_transitable(ex, ez):
                raise ValueError(
                    f"El punto de entrada de {edificio.lugar!r} en ({ex:.2f}, {ez:.2f}) no es transitable.")
        for nombre, (x, z) in self.spawns.items():
            if not self.es_transitable(x, z):
                raise ValueError(f"El spawn {nombre!r} en ({x}, {z}) no es transitable.")

    def escaleras(self):
        return list(self._escaleras)

    # Obstáculos que el modelo no conoce pero que el cliente dibuja con cuerpo (decorado de props_mundo, torres del
    # teleférico, puestos). Solo cambian es_transitable: obstaculos() (lo que se dibuja y lo que firma la huella de
    # la sala online) queda igual. `origen` agrupa: volver a llamar con el mismo origen REEMPLAZA esa lista, así es
    # idempotente si la ciudad 3D se reconstruye. Se descarta lo que tape un punto de entrada o un spawn (nunca deja
    # una puerta inalcanzable). Devuelve cuántos quedaron; 0 con la bandera apagada.
    def agregar_obstaculos(self, obstaculos, origen="decorado"):
        if not colision_decorado_activa():
            return 0
        protegidos = [e.punto_entrada() for e in self._edificios] + list(self.spawns.values())
        libres = [o for o in obstaculos
                  if not any(o.choca(x, z, self.radio_jugador) for x, z in protegidos)]
        viejos = self._extra.get(origen, [])
        self._extra[origen] = libres
        # Incremental: rehacer la rejilla entera costaba ~24 ms en el mapa grande (6000 obstáculos) en cada montar/bajar.
        # Solo se tocan las celdas de lo que sale y de lo que entra (el orden dentro de una celda no cambia el resultado).
        fuera = {id(o) for o in viejos}
        self._fisicos = [o for o in self._fisicos if id(o) not in fuera] + libres
        if self._celdas is not None:
            for celda in _indexar(viejos, self.radio_jugador):
                if celda in self._celdas:
                    self._celdas[celda] = [o for o in self._celdas[celda] if id(o) not in fuera]
            for celda, lista in _indexar(libres, self.radio_jugador).items():
                self._celdas.setdefault(celda, []).extend(lista)
        return len(libres)

    # Lo que agregar_obstaculos() añadió (por origen o todo): pruebas y depuración.
    def obstaculos_extra(self, origen=None):
        if origen is not None:
            return list(self._extra.get(origen, ()))
        return [o for lista in self._extra.values() for o in lista]

    # Muros de contención de los taludes (la colisión no los usa: el talud ya bloquea el paso).
    def muros(self):
        return list(self._muros)

    # Pasillos peatonales entre las casas de la favela (Callejon).
    def callejones(self):
        return list(self._callejones)

    # Áreas abiertas reservadas (Zona): cancha de fútbol, mercadito...
    def zonas(self):
        return list(self._zonas)

    # Altura del suelo en (x, z).
    def altura(self, x, z):
        return self.terreno.altura(x, z) if self.terreno is not None else 0.0

    # Altura que pisa el jugador: la del terreno, salvo sobre una Escalera, donde se cuantiza en peldaños
    # (backend/logica/escaleras_calculos.py). Solo la usan el controlador y el avatar; `altura()` sigue
    # siendo la malla suave del terreno (cámara, casas, props). Con ESCALERAS_PELDANOS = False es igual a altura().
    def altura_con_escaleras(self, x, z):
        base = self.altura(x, z)
        if not esc.ESCALERAS_PELDANOS or not self._escaleras:
            return base
        perfiles = self._perfiles_de_celda(x, z)
        if not perfiles:
            return base
        h = esc.altura_sobre_escaleras(perfiles, x, z)
        return base if h is None else h

    # Perfiles de las escaleras que tocan la celda de (x, z) (índice perezoso, ver esc.indice_por_celdas). Se rehace si
    # cambia la lista de perfiles.
    def _perfiles_de_celda(self, x, z):
        perfiles = self.perfiles_escaleras()
        cache = getattr(self, "_indice_escaleras", None)
        if cache is None or cache[0] is not perfiles or cache[1] != len(perfiles):
            cache = (perfiles, len(perfiles), esc.indice_por_celdas(perfiles))
            self._indice_escaleras = cache
        return cache[2].get((math.floor(x / esc.CELDA_INDICE), math.floor(z / esc.CELDA_INDICE)))

    # Perfiles de peldaños de cada escalera (mismo orden que escaleras()); el renderizador dibuja
    # exactamente estos peldaños. Sin terreno (mundo plano) no hay peldaños y la lista sale vacía.
    def perfiles_escaleras(self):
        if self._perfiles_escalera is None:
            if self.terreno is None:
                self._perfiles_escalera = []
            else:
                self._perfiles_escalera = [esc.PerfilEscalera(e, self.terreno.altura) for e in self._escaleras]
        return self._perfiles_escalera

    # Perfil de la escalera bajo (x, z) o None.
    def perfil_escalera_en(self, x, z):
        if self.terreno is None:
            return None
        perfiles = self.perfiles_escaleras()
        for k in self._indices_escaleras_en(x, z):
            if perfiles[k].escalera.contiene(x, z):
                return perfiles[k]
        return None

    # ¿Hay alguna escalera bajo (x, z)? (con o sin terreno; la usan es_transitable y los vehículos)
    def hay_escalera_en(self, x, z):
        return any(self._escaleras[k].contiene(x, z) for k in self._indices_escaleras_en(x, z))

    # Índices (en orden) de las escaleras que pueden contener (x, z): las de su celda, o todas sin índice.
    def _indices_escaleras_en(self, x, z):
        if not escaleras_indice_activo():
            return range(len(self._escaleras))
        if self._celdas_escaleras is None:
            celdas = {}
            for k, e in enumerate(self._escaleras):
                m = e.ancho / 2
                for i in range(math.floor((min(e.ax, e.bx) - m) / CELDA_ESCALERAS),
                               math.floor((max(e.ax, e.bx) + m) / CELDA_ESCALERAS) + 1):
                    for j in range(math.floor((min(e.az, e.bz) - m) / CELDA_ESCALERAS),
                                   math.floor((max(e.az, e.bz) + m) / CELDA_ESCALERAS) + 1):
                        celdas.setdefault((i, j), []).append(k)
            self._celdas_escaleras = {c: tuple(v) for c, v in celdas.items()}
        return self._celdas_escaleras.get((math.floor(x / CELDA_ESCALERAS), math.floor(z / CELDA_ESCALERAS)), ())

    # -- Delegación al mapa (lo que usa el GPS) --

    @property
    def mapa(self):
        return self._mapa

    @property
    def grafo(self):
        return self._mapa.grafo

    @property
    def ancho_calle(self):
        return self._mapa.ancho_calle

    @property
    def radio_plaza(self):
        return self._mapa.radio_plaza

    def coordenada(self, lugar):
        return self._mapa.coordenada(lugar)

    def lugares(self):
        return self._mapa.lugares()

    def segmentos(self):
        return self._mapa.segmentos()

    def lugar_en_plaza(self, x, z):
        return self._mapa.lugar_en_plaza(x, z)

    def calle_en(self, x, z):
        return self._mapa.calle_en(x, z)

    def lugar_mas_cercano(self, x, z):
        return self._mapa.lugar_mas_cercano(x, z)

    # -- Edificios y obstáculos --

    def edificios(self):
        return list(self._edificios)

    def obstaculos(self):
        return list(self._obstaculos)

    # ValueError si el lugar no tiene edificio.
    def edificio_de(self, lugar):
        if lugar not in self._por_lugar:
            raise ValueError(f"El lugar {lugar!r} no tiene edificio.")
        return self._por_lugar[lugar]

    # Donde se mide "llegué": la puerta del edificio; sin edificio, el centro del lugar
    # (así un mundo sin edificios se comporta como el mapa). ValueError si no existe.
    def punto_interaccion(self, lugar):
        if lugar in self._por_lugar:
            return self._por_lugar[lugar].puerta()
        return self._mapa.coordenada(lugar)

    # -- Movimiento --

    # (xmin, xmax, zmin, zmax): los límites del mapa ampliados para incluir los edificios.
    def limites(self):
        return self._limites

    # (xmin, xmax, zmin, zmax) donde se puede caminar: con terreno son los de la ladera dibujada
    # (menos MARGEN_BORDE_TERRENO); sin terreno o con RECORRER_TODO_EL_TERRENO = False, los de siempre.
    def limites_recorribles(self):
        return self._limites_recorribles

    # Transitable <=> dentro de los límites y el círculo del jugador no toca ningún obstáculo.
    def es_transitable(self, x, z):
        xmin, xmax, zmin, zmax = self._limites_recorribles
        if not (xmin <= x <= xmax and zmin <= z <= zmax):
            return False
        if (self.terreno is not None and not self.terreno.caminable(x, z)
                and not self.hay_escalera_en(x, z)):
            return False
        candidatos = self._fisicos if self._celdas is None else self._celdas.get(_celda(x, z), ())
        return not any(o.choca(x, z, self.radio_jugador) for o in candidatos)

    # -- Internos --

    def _calcular_limites(self, margen):
        xmin, xmax, zmin, zmax = self._mapa.limites()
        for e in self._edificios:
            ex0, ex1, ez0, ez1 = e.caja()
            xmin, xmax = min(xmin, ex0 - margen), max(xmax, ex1 + margen)
            zmin, zmax = min(zmin, ez0 - margen), max(zmax, ez1 + margen)
        return (xmin, xmax, zmin, zmax)

    # Los límites de siempre ampliados a la ladera dibujada (Terreno.extension), si hay terreno.
    def _calcular_limites_recorribles(self):
        xmin, xmax, zmin, zmax = self._limites
        extension = getattr(self.terreno, "extension", None)
        if not RECORRER_TODO_EL_TERRENO or extension is None:
            return self._limites
        ex0, ex1, ez0, ez1 = extension
        m = MARGEN_BORDE_TERRENO
        return (min(xmin, ex0 + m), max(xmax, ex1 - m), min(zmin, ez0 + m), max(zmax, ez1 - m))

    def _validar_edificio(self, edificio):
        mapa = self._mapa
        if edificio.lugar not in mapa.lugares():
            raise ValueError(f"Edificio de un lugar inexistente: {edificio.lugar!r}.")
        if edificio.lugar in self._por_lugar:
            raise ValueError(f"Hay dos edificios para {edificio.lugar!r} (lugar repetido).")
        caja = edificio.caja()
        for otro in self._por_lugar.values():
            if _cajas_se_solapan(caja, otro.caja()):
                raise ValueError(f"El edificio de {edificio.lugar!r} se solapa con el de {otro.lugar!r}.")
        for lugar in mapa.lugares():
            cx, cz = mapa.coordenada(lugar)
            if _distancia_punto_caja(cx, cz, caja) <= mapa.radio_plaza:
                raise ValueError(f"El edificio de {edificio.lugar!r} tapa la plaza de {lugar!r}.")
        semiancho = mapa.ancho_calle / 2
        for a, b in mapa.segmentos():
            if _distancia_segmento_caja(mapa.coordenada(a), mapa.coordenada(b), caja) <= semiancho:
                raise ValueError(f"El edificio de {edificio.lugar!r} tapa la calle {a!r} - {b!r}.")

    # La puerta está EN la fachada, así que su propio edificio siempre la "toca": no se le
    # exige ser transitable, solo estar dentro de los límites y que ningún OTRO obstáculo
    # la bloquee. Lo que sí es transitable es el punto de entrada, 1.2 m delante.
    def _puerta_libre(self, edificio):
        x, z = edificio.puerta()
        xmin, xmax, zmin, zmax = self._limites
        if not (xmin <= x <= xmax and zmin <= z <= zmax):
            return False
        propio = edificio.como_obstaculo()
        return not any(o.choca(x, z, self.radio_jugador) for o in self._fisicos if o != propio)

    def __repr__(self):
        return (f"MundoCiudad(lugares={len(self.lugares())}, edificios={len(self._edificios)}, "
                f"obstaculos={len(self._obstaculos)})")


# -- Rejilla de colisiones (ver INDICE_COLISIONES) --------------------------------------


def _celda(x, z):
    return math.floor(x / CELDA_COLISIONES), math.floor(z / CELDA_COLISIONES)


# {celda: [obstáculos]}: cada obstáculo en todas las celdas que toca su caja ensanchada `radio`.
def _indexar(obstaculos, radio):
    celdas = {}
    for o in obstaculos:
        if o.es_circulo:
            mx = mz = o.radio + radio
        else:
            mx, mz = o.ancho / 2 + radio, o.fondo / 2 + radio
        i0, j0 = _celda(o.cx - mx, o.cz - mz)
        i1, j1 = _celda(o.cx + mx, o.cz + mz)
        for i in range(i0, i1 + 1):
            for j in range(j0, j1 + 1):
                celdas.setdefault((i, j), []).append(o)
    return celdas


# -- Geometría auxiliar ----------------------------------------------------------------


def _cajas_se_solapan(a, b):
    return a[0] < b[1] and b[0] < a[1] and a[2] < b[3] and b[2] < a[3]


# Distancia del punto a la caja (xmin, xmax, zmin, zmax); 0 si está dentro.
def _distancia_punto_caja(x, z, caja):
    xmin, xmax, zmin, zmax = caja
    return math.hypot(x - min(max(x, xmin), xmax), z - min(max(z, zmin), zmax))


# Distancia mínima entre el segmento a-b y la caja; 0 si se cortan o el segmento está dentro.
# Si no se cortan, el mínimo se da entre un extremo del segmento y la caja, o entre una
# esquina de la caja y el segmento (distancia entre polígonos convexos).
def _distancia_segmento_caja(a, b, caja):
    if _segmento_corta_caja(a, b, caja):
        return 0.0
    xmin, xmax, zmin, zmax = caja
    esquinas = [(xmin, zmin), (xmin, zmax), (xmax, zmin), (xmax, zmax)]
    return min(
        _distancia_punto_caja(a[0], a[1], caja),
        _distancia_punto_caja(b[0], b[1], caja),
        *(_distancia_punto_segmento(esquina, a, b) for esquina in esquinas),
    )


# Recorte de Liang-Barsky del segmento contra la caja.
def _segmento_corta_caja(a, b, caja):
    xmin, xmax, zmin, zmax = caja
    t0, t1 = 0.0, 1.0
    dx, dz = b[0] - a[0], b[1] - a[1]
    for p, q in ((-dx, a[0] - xmin), (dx, xmax - a[0]), (-dz, a[1] - zmin), (dz, zmax - a[1])):
        if p == 0:
            if q < 0:
                return False
            continue
        t = q / p
        if p < 0:
            t0 = max(t0, t)
        else:
            t1 = min(t1, t)
        if t0 > t1:
            return False
    return True
